package com.sriyank.javatokotlindemo.models;


public class ErrorResponse {

	private String message;

	public String getMessage() {
		return message;
	}
}
